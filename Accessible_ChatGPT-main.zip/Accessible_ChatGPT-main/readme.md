
```bash
pip install -r requirement.txt
python -m spacy download en_core_web_sm

# get openai key at https://platform.openai.com/account/api-keys

python main.py
```
